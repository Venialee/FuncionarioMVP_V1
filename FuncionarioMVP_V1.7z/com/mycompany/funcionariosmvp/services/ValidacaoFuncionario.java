/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.services;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.model.Funcionario;
import com.mycompany.funcionariosmvp.presenter.TelaConsultaPresenter;
import com.mycompany.funcionariosmvp.presenter.TelaInclusaoPresenter;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexandre
 */
public class ValidacaoFuncionario {
    private TelaInclusaoPresenter telaInclusaoPresenter;
    private TelaConsultaPresenter telaConsultaPresenter;
    private FuncionarioCollection collection;
    
    public ValidacaoFuncionario(TelaInclusaoPresenter telaInclusaoPresenter, TelaConsultaPresenter telaConsultaPresenter, FuncionarioCollection collection){
        this.telaInclusaoPresenter = telaInclusaoPresenter;
        this.telaConsultaPresenter = telaConsultaPresenter;
        this.collection = collection;
    }
    
    public void validarFuncionario(){
        String nome = telaInclusaoPresenter.getTelaInclusaoView().getjTextFieldNome().getText();
        String cargo = telaInclusaoPresenter.getTelaInclusaoView().getjTextFieldCargo().getText();
        String salarioText = telaInclusaoPresenter.getTelaInclusaoView().getjTextFieldSalario().getText();
        if (!nome.isEmpty() && !cargo.isEmpty() && !salarioText.isEmpty()) {
            try {
                double salario = Double.parseDouble(salarioText);
                Funcionario funcionario = new Funcionario(nome, cargo, salario);
                collection.adicionarFuncionario(funcionario);
                telaConsultaPresenter.configuraTabela(collection);
                telaInclusaoPresenter.exibirMensagemSucesso();
            } catch (NumberFormatException e) {
                telaInclusaoPresenter.exibirMensagemFalha();
            }
        } else {
            telaInclusaoPresenter.exibirMensagemErro();
        }
    }
}
