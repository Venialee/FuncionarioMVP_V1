/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.funcionariosmvp;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.presenter.TelaConsultaPresenter;
import com.mycompany.funcionariosmvp.presenter.TelaInclusaoPresenter;
import com.mycompany.funcionariosmvp.presenter.TelaPrincipalPresenter;
import com.mycompany.funcionariosmvp.services.ValidacaoFuncionario;
import com.mycompany.funcionariosmvp.view.TelaConsultaView;
import com.mycompany.funcionariosmvp.view.TelaInclusaoView;
import com.mycompany.funcionariosmvp.view.TelaPrincipalView;

/**
 *
 * @author Alexandre
 */
public class FuncionariosMVP {

     public static void main(String[] args) {
        
        FuncionarioCollection collection = new FuncionarioCollection();
        
        TelaConsultaPresenter telaConsultaPresenter = new TelaConsultaPresenter(new TelaConsultaView(), collection);
        TelaInclusaoPresenter telaInclusaoPresenter = new TelaInclusaoPresenter(new TelaInclusaoView(), telaConsultaPresenter, collection);
        
        TelaPrincipalPresenter telaPrincipalPresenter = new TelaPrincipalPresenter(new TelaPrincipalView(), telaInclusaoPresenter, telaConsultaPresenter);
    }
     
}
