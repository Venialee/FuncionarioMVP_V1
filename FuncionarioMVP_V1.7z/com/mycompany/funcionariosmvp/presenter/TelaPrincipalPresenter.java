/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.presenter;

import com.mycompany.funcionariosmvp.view.TelaPrincipalView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Alexandre
 */
public class TelaPrincipalPresenter {
    private TelaInclusaoPresenter telaInclusaoPresenter;
    private TelaConsultaPresenter telaConsultaPresenter;
    private TelaPrincipalView telaPrincipalView;
    
    public TelaPrincipalPresenter(TelaPrincipalView telaPrincipalView, TelaInclusaoPresenter telaInclusaoPresenter, TelaConsultaPresenter telaConsultaPresenter){
        this.telaConsultaPresenter = telaConsultaPresenter;
        this.telaInclusaoPresenter = telaInclusaoPresenter;
        this.telaPrincipalView = telaPrincipalView;
        this.telaPrincipalView.setVisible(true);
        cadastrarFuncionario();
        consultarFuncionario();
    }
    
    public void cadastrarFuncionario(){
        telaPrincipalView.getjButtonInclusao().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                telaInclusaoPresenter.getTelaInclusaoView().setVisible(true);
            }
        });
    }
    
    public void consultarFuncionario(){
        telaPrincipalView.getjButtonConsultar().addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
                telaConsultaPresenter.getTelaConsultaView().setVisible(true);
            }
        });
    }
}
