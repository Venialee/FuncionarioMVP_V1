/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.presenter;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.model.Funcionario;
import com.mycompany.funcionariosmvp.view.TelaInclusaoView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Alexandre
 */
public class TelaVisualizacaoPresenter {
    private FuncionarioCollection collection;
    private Funcionario funcionario;
    private TelaConsultaPresenter telaConsultaPresenter;
    private TelaInclusaoView telaInclusaoView;
    
    public TelaVisualizacaoPresenter(TelaInclusaoView telaInclusaoView, FuncionarioCollection collection){
        this.collection = collection;
        this.funcionario = funcionario;
        this.telaInclusaoView = telaInclusaoView;
        this.telaInclusaoView.setVisible(false);
        janelaResultado();
        voltar();
    }    
    
    public void janelaResultado( ){
        if(funcionario != null) {
            this.telaInclusaoView.getjTextFieldNome().setEditable(false);
            this.telaInclusaoView.getjTextFieldCargo().setEditable(false);
            this.telaInclusaoView.getjTextFieldSalario().setEditable(false);
            this.telaInclusaoView.getjTextFieldNome().setText(funcionario.getNome());
            this.telaInclusaoView.getjTextFieldCargo().setText(funcionario.getCargo());
            this.telaInclusaoView.getjTextFieldSalario().setText(Double.toString(funcionario.getSalario()));
            desabilitarBotao();
            this.telaInclusaoView.setVisible(true);
        }
    }
    
    public void desabilitarBotao(){
        telaInclusaoView.getjButtonSalvar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                telaInclusaoView.getjButtonSalvar().setEnabled(false);
            }
        });
    }
    
    public void voltar(){
        telaInclusaoView.getjButtonCancelar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                telaInclusaoView.setVisible(false);
            }
        });
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public FuncionarioCollection getCollection() {
        return collection;
    }

    public void setCollection(FuncionarioCollection collection) {
        this.collection = collection;
    }

    public TelaConsultaPresenter getTelaConsultaPresenter() {
        return telaConsultaPresenter;
    }

    public void setTelaConsultaPresenter(TelaConsultaPresenter telaConsultaPresenter) {
        this.telaConsultaPresenter = telaConsultaPresenter;
    }

    public TelaInclusaoView getTelaInclusaoView() {
        return telaInclusaoView;
    }

    public void setTelaInclusaoView(TelaInclusaoView telaInclusaoView) {
        this.telaInclusaoView = telaInclusaoView;
    }

}
