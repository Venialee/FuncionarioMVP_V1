/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.presenter;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.services.ValidacaoFuncionario;
import com.mycompany.funcionariosmvp.view.TelaInclusaoView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexandre
 */
public class TelaInclusaoPresenter {
    
    private TelaInclusaoView telaInclusaoView;
    private FuncionarioCollection collection;
    private TelaConsultaPresenter telaConsultaPresenter;
    private ValidacaoFuncionario validacaoFuncionario;
    
    public TelaInclusaoPresenter(TelaInclusaoView telaInclusaoView, TelaConsultaPresenter telaConsultaPresenter, FuncionarioCollection collection){
        this.collection = collection;
        this.telaConsultaPresenter = telaConsultaPresenter;
        this.telaInclusaoView = telaInclusaoView;
        validacaoFuncionario = new ValidacaoFuncionario(this, telaConsultaPresenter, collection);
        this.telaInclusaoView.setVisible(false);
        configuraTela();
    }
    
    public void configuraTela(){
        telaInclusaoView.getjButtonSalvar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validacaoFuncionario.validarFuncionario();
            }
        });
        
        telaInclusaoView.getjButtonCancelar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                telaInclusaoView.dispose();
            }
        });
    }
    
    public void exibirMensagemSucesso(){
        JOptionPane.showMessageDialog(telaInclusaoView, "Funcionário cadastrado com sucesso.");
    }
    
    public void exibirMensagemFalha(){
        JOptionPane.showMessageDialog(telaInclusaoView, "O valor do salário não é válido.");
    }
    
    public void exibirMensagemErro() {
        JOptionPane.showMessageDialog(telaInclusaoView, "Preencha todos os campos corretamente.");
    }
    
    public TelaInclusaoView getTelaInclusaoView() {
        return telaInclusaoView;
    }

    public FuncionarioCollection getCollection() {
        return collection;
    }

    public TelaConsultaPresenter getTelaConsultaPresenter() {
        return telaConsultaPresenter;
    }

    public ValidacaoFuncionario getValidacaoFuncionario() {
        return validacaoFuncionario;
    }
}
